package zz;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;

/**
 * Servlet implementation class Lo
 */
public class Lo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Lo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doGet(request, response);
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");
		Subject su = SecurityUtils.getSubject();
		UsernamePasswordToken user = new UsernamePasswordToken(name,pass);
		su.login(user);
		if(su.isAuthenticated()) {
			System.out.println("��¼�ɹ�");
			if(su.hasRole("ROLE_USER")) {
				System.out.println("��¼�ɹ�  �ݻ����н�ɫ");	
			}
		}else {System.out.println("��¼ʧ��");
			
		}
	}

}
