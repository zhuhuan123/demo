package zz.controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.UnauthorizedException;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyC {

	@RequestMapping(value="g")
	public String g() {
		
		return "g";
	}
	
	@ResponseBody
	@RequiresRoles(value="ROLE_USER")
	@RequestMapping(value="rea")
	public String read() {
		System.out.println("���ﲻ��Ҫ��֤��ôִ��");
		Subject su = SecurityUtils.getSubject();
		System.out.println("s��i��һou   �Ƿ��н�ɫ   "+su.hasRole("ROLE_USER"));
		return "g";
	}
	
	@ResponseBody
	@RequiresRoles(value="ROLE_ADMIN")
	@RequestMapping(value="readd")
	public String readd() {
		System.out.println("���ﲻ��Ҫ��֤��ôִ������    ne");
//		Subject su = SecurityUtils.getSubject();
//		System.out.println("s��i��һou   �Ƿ��н�ɫ   "+su.hasRole("ROLE_USER"));
		return "g";
	}
	
	@ExceptionHandler({UnauthorizedException.class})  
	public ModelAndView processUnauthenticatedException(NativeWebRequest request, UnauthorizedException e) {  
	    ModelAndView mv = new ModelAndView();  
	    mv.addObject("exception", e);  
	    mv.setViewName("unauthorized");  
	    return mv;  
	} 
	@ExceptionHandler({AuthorizationException.class})  
	public ModelAndView processAuthorizationException(NativeWebRequest request, AuthorizationException e) {  
	    ModelAndView mv = new ModelAndView();  
	    e.printStackTrace();
	    mv.addObject("exception", e);  
	    mv.setViewName("unauthorized");  
	    return mv;  
	} 
}
